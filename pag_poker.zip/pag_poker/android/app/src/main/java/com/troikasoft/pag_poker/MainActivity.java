package com.troikasoft.pag_poker;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

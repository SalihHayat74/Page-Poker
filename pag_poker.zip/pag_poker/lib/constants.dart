import 'package:flutter/material.dart';

Color mainBackgroundColor =const Color(0xffB8B8B8);
Color mainThemeColor =const Color(0xff2F0F5D);
Color neonColor = const Color(0xff16FF00);
Color whiteColor = const Color(0xffffffff);
Color blackColor = const Color(0xff000000);